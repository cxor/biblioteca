drop DATABASE if exists BIBLIOTECA;

create DATABASE BIBLIOTECA;

GRANT ALL ON BIBLIOTECA.*  TO  'utentebiblioteca'@'localhost'  IDENTIFIED BY  'password' ; 

USE BIBLIOTECA



#
#	CREAZIONE TABELLE PER LE ENTITà
#

create table Utente (
	
	id_utente    			int AUTO_INCREMENT PRIMARY KEY,
	email 		 			varchar(50) 	 not NULL,
	password	 			varchar(50)	 	 not NULL,
	tipo		 			varchar(50) 	 not NULL default 'PASSIVO',
	num_inserimenti 		int 			 default 0,
	 	
	CONSTRAINT UNICA_EMAIL 	unique(email)
);

create table Anagrafica (

	id_utente  				int			 PRIMARY KEY,
	nome  		 			varchar(50) 	not NULL,
	cognome		 			varchar(50) 	not NULL,	
	cf		 				varchar(50)	 			,
	data_nascita  			DATE	     	not NULL,
	luogo_nascita 			varchar(50) 	not NULL,
	nazionalita				varchar(50) 	not NULL,
	
	CONSTRAINT ANAGRAFICA_UTENTE FOREIGN KEY (id_utente) REFERENCES Utente(id_utente) ON DELETE CASCADE,
	CONSTRAINT UNICA_ANAGRAFICA unique(cf)
);

create table Pubblicazione (

	id_pubblicazione 		int 			AUTO_INCREMENT PRIMARY KEY,
	titolo		 			varchar(50) 	not NULL,
	data_inserimento 		TIMESTAMP 		default CURRENT_TIMESTAMP, 
	data_ultima_modifica 	TIMESTAMP 		default CURRENT_TIMESTAMP,
	categoria 				varchar(50) 	not NULL,
	numlike		 			int 			default 0
	
);

create table Metadati (

	id_pubblicazione		int,
	edizione				int default 1 not NULL,
	editore					varchar(50),
	data_pubblicazione 		DATE,
	parole_chiave			varchar(50),
	isbn					BIGINT PRIMARY KEY,
	num_pagine				int,
	lingua					varchar(50),
	sinossi					varchar(500),
	
	CONSTRAINT UNICO_EDIZIONE UNIQUE (edizione ,id_pubblicazione ),
	CONSTRAINT METADATI_PUBBLICAZIONE FOREIGN KEY(id_pubblicazione) REFERENCES Pubblicazione(id_pubblicazione)
);

create table Autore (

	id_autore 				int AUTO_INCREMENT PRIMARY KEY,
	nome 					varchar(50) not NULL,
	cognome 				varchar(50) not NULL,
	
	CONSTRAINT UNICO_AUTORE UNIQUE (nome ,cognome )
);


create table Capitolo (

	id_capitolo				int AUTO_INCREMENT PRIMARY KEY,
	id_pubblicazione 		int not NULL,
	titolo					varchar(50) not NULL,
	descrizione				varchar(500),
	num_capitolo			int not NULL,
	
	CONSTRAINT CAPITOLO_PUBBLICAZIONE FOREIGN KEY(id_pubblicazione) REFERENCES Pubblicazione(id_pubblicazione),
	CONSTRAINT UNICO_CAPITOLO unique (id_pubblicazione,num_capitolo)
);

create table Versione_Stampa (

	id_versione_stampa		int AUTO_INCREMENT PRIMARY KEY,
	isbn 					BIGINT not NULL,
	num_copie 				int not NULL,
	data_stampa				DATE,
	
	CONSTRAINT VERSIONESTAMPA_METADATI FOREIGN KEY(isbn) REFERENCES Metadati(isbn)
);


create table Mediatype (

	id_mediatype	 		int AUTO_INCREMENT PRIMARY KEY,
	tipo					varchar(50) not NULL,
	formato					varchar(50) not NULL
);

create table Risorse (

	id_risorsa		 		int AUTO_INCREMENT PRIMARY KEY,
	id_mediatype			int not NULL,
	uri						varchar(50) not NULL,
	descrizione				varchar(500),

	CONSTRAINT RISORSE_MEDIATYPE FOREIGN KEY(id_mediatype) REFERENCES Mediatype(id_mediatype)
);


#
#CREAZIONE TABELLE PER RELAZIONI
#

create table Recensione (

	id_utente				int not NULL,
	id_pubblicazione	 	int not NULL,
	data 					TIMESTAMP default CURRENT_TIMESTAMP,
	stato 					varchar(50) not NULL default 'IN ATTESA',
	testo 					varchar(1000),
	
	CONSTRAINT RECENSIONE_PUBBLICAZIONE FOREIGN KEY(id_pubblicazione) REFERENCES Pubblicazione(id_pubblicazione),
	CONSTRAINT RECENSIONE_UTENTE FOREIGN KEY (id_utente) REFERENCES Utente(id_utente),
	CONSTRAINT UNICA_RECENSIONE unique(id_utente , id_pubblicazione)
);
	
	
# La tabella sottostante Gradimento corrisponde alla tabella Like, tuttavia MySQL non permette di utilizzare like (keyword riservata )

create table Gradimento (

	id_utente				int not NULL,
	id_pubblicazione 		int not NULL,
	data					TIMESTAMP default CURRENT_TIMESTAMP,
	
	CONSTRAINT GRADIMENTO_UTENTE FOREIGN KEY (id_utente) REFERENCES Utente (id_utente) ON DELETE CASCADE,
	CONSTRAINT GRADIMENTO_PUBBLICAZIONE FOREIGN KEY (id_pubblicazione) REFERENCES Pubblicazione(id_pubblicazione) ON DELETE CASCADE,
	CONSTRAINT UNICO_LIKE unique(id_utente,id_pubblicazione)
);


create table Storico (

	id_utente		 		int not NULL,
	id_pubblicazione		int not NULL,
	data					TIMESTAMP default CURRENT_TIMESTAMP,
	descrizione				varchar(1000) not NULL,
	operazione 				varchar(50) not NULL,

	CONSTRAINT LOG_UTENTE FOREIGN KEY (id_utente) REFERENCES Utente (id_utente),
	CONSTRAINT LOG_PUBBLICAZIONE FOREIGN KEY (id_pubblicazione) REFERENCES Pubblicazione(id_pubblicazione)
);


create table Attribuzione(

	isbn			 		BIGINT not NULL,
	id_autore 				int not NULL,

	CONSTRAINT ATTRIBUZIONE_METADATI FOREIGN KEY (isbn) REFERENCES Metadati(isbn),
	CONSTRAINT ATTRIBUZIONE_AUTORE FOREIGN KEY (id_autore) REFERENCES Autore(id_autore),
	CONSTRAINT UNICA_ATTRIBUZIONE unique(isbn, id_autore)
);


create table Link (

	id_pubblicazione		int not NULL,
	id_risorsa				int not NULL,
	
	CONSTRAINT LINK_PUBBLICAZIONE FOREIGN KEY (id_pubblicazione) REFERENCES Pubblicazione(id_pubblicazione),
	CONSTRAINT LINK_RISORSA FOREIGN KEY (id_risorsa) REFERENCES Risorse(id_risorsa)	,
	CONSTRAINT UNICO_LINK unique(id_pubblicazione, id_risorsa)
);



#
# _In questo script sono presenti tutte le operazioni CRUD sulle tabelle del DB
#



#
# modifica del delimitatore , setto  il carattere $
#

DELIMITER $



#
#	procedure tabella UTENTE
#

drop procedure if exists aggiungi_utente ;
create procedure aggiungi_utente( in EMAILUTENTE varchar(250), in PASSWD varchar(250) ) 

	begin

		insert into Utente(email,password) value ( EMAILUTENTE,PASSWORD(PASSWD) );

	end $ 




drop procedure if exists  cancella_utente ;
create procedure cancella_utente(in EMAILUTENTE varchar(250) )

	begin

		delete from Utente where email = EMAILUTENTE ;

	end $




drop procedure if exists  aggiorna_email ;
create procedure aggiorna_email (in EMAILVECCHIA varchar(250) , in EMAILNUOVA varchar(250) )

	begin

		update Utente set email = EMAILNUOVA where email = EMAILVECCHIA ;

	end $





drop procedure if exists  aggiorna_password ;
create procedure aggiorna_password(in PASSWORD varchar(250) , in EMAILUTENTE varchar(250) )

	begin

		update Utente set password = PASSWORD where email = EMAILUTENTE ;

	end $





drop procedure if exists  aggiorna_tipo_attivo ;
create procedure aggiorna_tipo_attivo( in EMAILUTENTE varchar(250) )

	begin 

		update Utente set tipo = 'ATTIVO' where email = EMAILUTENTE ;

	end $






drop procedure if exists  aggiorna_tipo_passivo ;
create procedure aggiorna_tipo_passivo( in EMAILUTENTE varchar(250) )

	begin 

		update Utente set tipo = 'PASSIVO' where email = EMAILUTENTE ;

	end $






drop procedure if exists  aggiorna_tipo ;
create procedure aggiorna_tipo( in EMAILUTENTE varchar(250) , in TIPO varchar(250) )

	begin 

		update Utente set tipo = TIPO where email = EMAILUTENTE ;

	end $



drop procedure if exists  aggiorna_num_pubblicazione ;
create procedure aggiorna_num_pubblicazione( in EMAILUTENTE varchar(250) )

	begin 

		update Utente set num_inserimenti = num_inserimenti+ 1 where email = EMAILUTENTE ;

	end $




#
#	procedure CRUD ANAGRAFICA
#

drop procedure if exists  aggiungi_anagrafica ;
create procedure aggiungi_anagrafica 

(
	in IDUTENTE int,
	in NOME  varchar(250),
	in COGNOME varchar(250),
	in CF varchar(250),
	in DATADINASCITA DATE,
	in LUOGODINASCITA varchar(250),
	in NAZIONE varchar(250)
)

	begin

		insert into Anagrafica value (IDUTENTE,NOME,COGNOME,CF,DATADINASCITA,LUOGODINASCITA,NAZIONE) ;

	end $	





drop procedure if exists  cancella_anagrafica ;
create procedure cancella_anagrafica ( in IDUTENTE int )

	begin
	
		delete from Anagrafica where id_utente = IDUTENTE ;

	end $


#procedure PER AGGIORNAMENTO


#update NOME

drop procedure if exists  aggiorna_nome ;
create procedure aggiorna_nome (in NUOVONOME varchar(250) , in IDUTENTE int )

	begin
	
		update Anagrafica set nome= NUOVONOME where id_utente = IDUTENTE ;

	end $





#update COGNOME
drop procedure if exists  aggiorna_cognome ;
create procedure aggiorna_cognome(in NUOVOCOGNOME varchar(250), in IDUTENTE int)

	begin

        update Anagrafica set cognome= NUOVOCOGNOME where id_utente = IDUTENTE ;

    end $





#update CODICE FISCALE
drop procedure if exists  aggiorna_cf ;
create procedure aggiorna_cf ( in NUOVOCF varchar(250) , in IDUTENTE int )

        begin
	
	        update Anagrafica set cf = NUOVOCF where id_utente = IDUTENTE ;

        end $





#update DATA DI NASCITA
drop procedure if exists  aggiorna_data_nascita ;
create procedure aggiorna_data_nascita (in NUOVADATA Date, in IDUTENTE int )

        begin

	        update Anagrafica set data_nascita= NUOVADATA where id_utente = IDUTENTE ;

        end $





#update LUOGO DI NASCITA
drop procedure if exists  aggiorna_luogo_nascita ;
create procedure aggiorna_luogo_nascita(in NUOVOLUOGO varchar(250), in IDUTENTE int)

        begin

	        update Anagrafica set luogo_nascita = NUOVOLUOGO where id_utente = IDUTENTE;

        end $






#update NAZIONE
drop procedure if exists  aggiorna_nazionalita ;
create procedure aggiorna_nazionalita (in NUOVANAZIONE varchar(250), in IDUTENTE int)

        begin

	        update Anagrafica set nazionalita = NUOVANAZIONE where id_utente = IDUTENTE ;

        end $





#
#procedure CRUD  PUBBLICAZIONE
#
drop procedure if exists  aggiungi_pubblicazione ;
create procedure aggiungi_pubblicazione 
	(
		in TITOLO varchar(250) ,
		in CATEG  varchar(250) 
		
	)
	
	begin
	
		insert into Pubblicazione (titolo, categoria  ) value ( TITOLO , CATEG );
	
	end $





drop procedure if exists  cancella_pubblicazione ;
create procedure cancella_pubblicazione (in IDPUBB int )
	
	begin
	
		delete from Pubblicazione where id_pubblicazione = IDPUBB ; 
	
	end $





drop procedure if exists  aggiorna_titolo ;
create procedure aggiorna_titolo   (in IDPUBB int , in STRNG varchar(250) , in email varchar(250) )
	
	begin
	
		update Pubblicazione set titolo = STRNG where id_pubblicazione = IDPUBB ; 
		 
	end $





drop procedure if exists  aggiorna_categoria ;
create procedure aggiorna_categoria(in IDPUBB int , in STRNG varchar(250))
	
	begin
	
		update Pubblicazione set categoria = STRNG where id_pubblicazione = IDPUBB ; 
	
	end $






#
#	procedure METADATI
#


drop procedure if exists  aggiungi_metadati ;
create procedure aggiungi_metadati 
	(
		in IDPUBB 			int,
		in EDIZIONE			int,
		in EDITORE			varchar(250),
		in DATAPUBB 		DATE,
		in PAROLECHIAVE		varchar(250),
		in ISBN				BIGINT,
		in NUMPAGINE		int,
		in LINGUA			varchar(250),
		in SINOSSI			varchar(1000)
	)

	begin
	
		insert into Metadati value (IDPUBB, EDIZIONE ,EDITORE,DATAPUBB ,PAROLECHIAVE ,ISBN ,NUMPAGINE ,LINGUA ,SINOSSI);
	
	end $






drop procedure if exists  cancella_metadati ;
create procedure cancella_metadati ( in _ISBN BIGINT )
	
	begin
	
		delete from Metadati where isbn = _ISBN ;
	
	end $






drop procedure if exists  aggiorna_edizione_metadati ;
create procedure aggiorna_edizione_metadati (in EDI int , in _ISBN BIGINT )
	
	begin
	
		update Metadati set edizione = EDI where isbn = _ISBN ; 
	
	end $





drop procedure if exists  aggiorna_editore_metadati ;
create procedure aggiorna_editore_metadati (in EDI varchar(50) , in _ISBN BIGINT )
	
	begin
	
		update Metadati set editore = EDI where isbn = _ISBN ; 
	
	end $





drop procedure if exists  aggiorna_data_pubblicazione_metadati ;
create procedure aggiorna_data_pubblicazione_metadati (in DATAPUBB DATE , in ISBN BIGINT )
	
	begin
	
		update Metadati set data_pubblicazione = DATAPUBB where isbn = ISBN ; 
	
	end $





drop procedure if exists  aggiorna_parole_chiave_metadati ;
create procedure aggiorna_parole_chiave_metadati (in PAROLECHIAVE varchar(250) , in ISBN BIGINT )
	
	begin
	
		update Metadati set parole_chiave = PAROLECHIAVE where isbn = ISBN ; 
	
	end $






drop procedure if exists  aggiorna_isbn_metadati ;
create procedure aggiorna_isbn_metadati (in ISBNNEW int(13), in ISBN BIGINT )
	
	begin
	
		update Metadati set isbn = ISBNNEW where isbn = ISBN ; 
	
	end $






drop procedure if exists  aggiorna_num_pagine_metadati ;
create procedure aggiorna_num_pagine_metadati (in NUMPAGINE int,in ISBN BIGINT )
	
	begin
	
		update Metadati set num_pagine = NUMPAGINE where isbn = ISBN ; 
	
	end $







drop procedure if exists  aggiorna_lingua_metadati ;
create procedure aggiorna_lingua_metadati (in LINGUA varchar(250),in ISBN BIGINT )
	
	begin
	
		update Metadati set lingua = LINGUA where isbn = ISBN ; 
	
	end $







drop procedure if exists  aggiorna_sinossi_metadati ;
create procedure aggiorna_sinossi_metadati (in SINOSSI varchar(1000) , in ISBN BIGINT )
	
	begin
	
		update Metadati set sinossi = SINOSSI where isbn = ISBN ; 
	
	end $








#
#procedure CRUD AUTORE
#


drop procedure if exists  aggiungi_autore ;
create procedure aggiungi_autore  ( in NOME varchar(250) , in COGNOME varchar(250) )

	begin

		insert into Autore ( nome , cognome ) value ( NOME , COGNOME );

	end $







drop procedure if exists  cancella_autore ;
create procedure cancella_autore ( in IDAUT int)

	begin

		delete from Autore where id_autore = IDAUT ;

	end $



drop procedure if exists  aggiorna_nome_autore ;
create procedure  aggiorna_nome_autore( in NOME varchar(250), in IDAUT int)

	begin

		update Autore set nome =NOME where id_autore = IDAUT ;

	end $






drop procedure if exists  aggiorna_cognome_autore ;
create procedure  aggiorna_cognome_autore( in COGNOME varchar(250), in IDAUT int)

	begin

		update Autore set cognome =COGNOME where id_autore = IDAUT ;

	end $



#
# procedure CAPITOLO
#

drop procedure if exists  aggiungi_capitolo ;
create procedure aggiungi_capitolo
	(
		IDPUBB			int,
		TITOLO  		varchar(250) ,
		DESCRIZIONE		varchar(1000) ,
		NUMCAP			int
	)

	begin

		insert into Capitolo (id_pubblicazione , titolo , descrizione , num_capitolo)  value (IDPUBB , TITOLO, DESCRIZIONE , NUMCAP);

	end $










drop procedure if exists  cancella_capitolo ;
create procedure cancella_capitolo ( in IDCAP int )

	begin

		delete from Capitolo where id_capitolo = IDCAP ;

	end $






drop procedure if exists  aggiorna_titolo_capitolo ;
create procedure  aggiorna_titolo_capitolo( in TITOLO varchar(250), in IDCAP int)

	begin

		update Capitolo set titolo = TITOLO where id_capitolo = IDAUT ;

	end $








drop procedure if exists  aggiorna_descrizione_capitolo ;
create procedure  aggiorna_descrizione_capitolo( in DESCRIZIONE varchar(1000), in IDCAP int)

	begin

		update Capitolo set descrizione = DESCRIZIONE where id_capitolo = IDAUT ;

	end $






drop procedure if exists  aggiorna_num_capitolo ;
create procedure  aggiorna_num_capitolo( in NUMCAP int, in IDCAP int)

	begin

		update Capitolo set num_capitolo = NUMCAP where id_capitolo = IDAUT ;

	end $







#
#procedure VERSIONE_STAMPA
#


drop procedure if exists  aggiungi_versione_stampa ;
create procedure aggiungi_versione_stampa
	(	
		CODICEISBN 		BIGINT ,
		NUMCOP 		int ,
		DATASTAMP	DATE
	)

	begin

		insert into Versione_Stampa ( isbn ,num_copie ,data_stampa ) value (CODICEISBN,NUMCOP ,DATASTAMP);

	end $







drop procedure if exists  aggiorna_num_copie_versione_stampa ;
create procedure  aggiorna_num_copie_versione_stampa( in NUMCOP int, in IDVER int)

	begin

		update Versione_Stampa set num_copie = NUMCOP where id_versione_stampa = IDVER ;

	end $





drop procedure if exists  aggiorna_data_versione_stampa ;
create procedure  aggiorna_data_versione_stampa ( in DATAVER DATE, in IDVER int )

	begin

		update Versione_Stampa set data_stampa = DATAVER where id_versione_stampa = IDVER ;

	end $







drop procedure if exists  cancella_versione_stampa ;
create procedure cancella_versione_stampa (in IDVER int )

	begin

		delete from Versione_Stampa where id_versione = IDVER ;

	end $
#
#procedure MEDIATYPE
#







drop procedure if exists  aggiungi_mediatype ;
create procedure aggiungi_mediatype 
	(
		in TIPO			varchar(250) ,
		in FORMATO		varchar(250)	
	)

	begin

		insert into Mediatype (tipo , formato) value ( TIPO , FORMATO ) ;

	end $








drop procedure if exists  aggiorna_tipo_mediatype ;
create procedure aggiorna_tipo_mediatype (in TIPO varchar(250) , in IDVER int )

	begin

		update Mediatype set tipo = TIPO where id_mediatype = IDVER ;

	end $








drop procedure if exists  aggiorna_formato_mediatype ;
create procedure aggiorna_formato_mediatype (in FORMATO varchar(250) , in IDVER int )

	begin

		update Mediatype set formato = FORMATO where id_mediatype = IDVER ;

	end $







#
# procedure RISORSE
#

drop procedure if exists  aggiungi_risorse ;
create procedure aggiungi_risorse 
	(	
		in IDMEDIA int ,
		in URI	varchar(250),
		in DESCR varchar(1000)
	)

	begin

		insert into Risorse  (id_mediatype , uri , descrizione )value (IDMEDIA , URI , DESCR);

	end $





drop procedure if exists  aggiorna_uri_risorse ;
create procedure aggiorna_uri_risorse (in URI varchar(250) , in IDRISORSA int )

	begin

		update Risorse set uri = URI where id_risorsa = IDRISORSA ;	

	end $







drop procedure if exists  aggiorna_formato_risorse ;
create procedure aggiorna_formato_risorse (in DESCRIZ varchar(250) , in IDRISORSA int )

	begin

		update Risorse set descrizione = DESCRIZ where id_risorsa = IDRISORSA ;	

	end $



#
# PROEDURE RECENSIONE
#

drop procedure if exists  aggiungi_recensione ;
create procedure aggiungi_recensione 
	(
		in IDUTENTE int ,
		IDPUBB 	int,
		in TESTO varchar(1000)	
	)

	begin

		insert into Recensione ( id_utente , id_pubblicazione , testo) value (IDUTENTE , IDPUBB , TESTO);

	end $










drop procedure if exists  cancella_recensione ;
create procedure cancella_recensione (in IDUTENTE int , in IDPUBB int)

	begin

		delete from Recensione where id_utente = IDUTENTE and id_pubblicazione = IDPUBB ;
		
	end $







drop procedure if exists  aggiorna_stato_recensione ;
create procedure aggiorna_stato_recensione ( in IDUTENTE int , in IDPUBB int )

	begin

		update Recensione set stato = 'APPROVATA' where id_utente = IDUTENTE and id_pubblicazione = IDPUBB ;

	end $







drop procedure if exists  aggiorna_testo_recensione ;
create procedure aggiorna_testo_recensione (in IDUTENTE int , in IDPUBB int , in TESTO varchar(1000) )

	begin

		update Recensione set testo = TESTO and stato = 'in ATTESA' and data = CURRENT_TIMESTAMP where id_utente = IDUTENTE and id_pubblicazione = IDPUBB ;

	end $






#
# procedure GRADIMENTO
#

drop procedure if exists  aggiungi_gradimento ;
create procedure aggiungi_gradimento ( in IDUTENTE int , in IDPUBB int )

	begin

		insert into Gradimento  ( id_utente , id_pubblicazione ) value (IDUTENTE , IDPUBB );

	end $







drop procedure if exists  cancella_gradimento ;
create procedure cancella_gradimento (in IDUTENTE int , in IDPUBB int )

	begin

		delete from Gradimento where id_utente = IDUTENTE and id_pubblicazione = IDPUBB ;

	end $





#
# procedure ATTRIBUZIONE
#

drop procedure if exists  aggiungi_attribuzione ;
create procedure aggiungi_attribuzione ( in IDISBN BIGINT , in IDAUT int )

	begin

		insert into Attribuzione value (IDISBN , IDAUT );

	end $




drop procedure if exists  cancella_attribuzione ;
create procedure cancella_attribuzione (in IDISBN BIGINT , in IDAUT int )

	begin

		delete from Attribuzione where  id_pubblicazione = IDISBN and id_autore = IDAUT ;

	end $





#
# procedure LINK
#

drop procedure if exists  aggiungi_link ;
create procedure aggiungi_link( in IDPUBB int,in IDRIS int )

	begin

		insert into Link value (IDPUBB , IDRIS );

	end $




drop procedure if exists  cancella_link ;
create procedure cancella_link (in IDPUBB int , in IDRIS int )

	begin

		delete from Link where id_pubblicazione = IDPUBB and id_risorsa= IDRIS;

	end $




#
#procedure STORICO
#
drop procedure if exists  aggiungi_storico ;
create procedure aggiungi_storico ( in idut int , in idpubb int , in descr varchar(1000) , in oper varchar(50) )
	
	begin
	
		insert into Storico (id_utente,id_pubblicazione, descrizione , operazione ) value ( idut , idpubb , descr , oper ) ;

	end $

	





#
# reimposto il delimitatore ;
#

DELIMITER $


#
# Questo script definisce alcune utility 
# funzioni helper per _procedure e _trigger
#

#
# Imposto un nuovo delimitatore ,setto a $
#

delimiter $


#
# funzione per _check tipologia utente 
#

drop function if exists check_tipo_utente ;
create function check_tipo_utente ( email_utente varchar(100) ) returns integer
		READS SQL DATA

		
		begin
		
			return (select if ( (select tipo from Utente where email = email_utente) = 'ATTIVO', 1 , 0 ) ) ;
		
		end $


drop function if exists check_tipo_id_utente ;
create function check_tipo_id_utente ( idUtente int ) returns integer
		READS SQL DATA

		begin
		
			return (select if ( (select tipo from Utente where id_utente = idUtente) = 'ATTIVO', 1 , 0 ) ) ;
		
		end $






# funzione che recupera l ID di una pubblicazione dato il titolo 


drop function if exists get_id_pubblicazione;
create function get_id_pubblicazione( tit_pubb varchar(100) ) returns integer
		READS SQL DATA

		begin

			return ( select id_pubblicazione from Pubblicazione where titolo = tit_pubb );

		end $


#funzione che dato isbn ritorna l id_pubblicazione associato

drop function if exists get_id_pubblicazione_by_isbn ;
create function	get_id_pubblicazione_by_isbn (id_isbn varchar(250) ) returns integer
		READS SQL DATA

		begin

			return (select id_pubblicazione from Metadati where isbn = id_isbn );

		end $





# funzione che restituisce l ID di un utente data la mail

drop function if exists get_id_utente;
create function get_id_utente( emailutente varchar(100) ) returns integer
		READS SQL DATA

		begin

			return ( select id_utente from Utente where email = emailutente );

		end $





#funzione che recupera la mail di chi ha inserito un metadato

drop function if exists get_email_by_id ;
create function get_email_by_id ( var_id bigint ) returns varchar(100)
		READS SQL DATA

		begin

			return ( select email From Utente where  id_utente = var_id );	
	
		end $




#funzione che recupera il titolo di una pubblicazione dato il suo id

drop function if exists get_titolo_pubblicazione;
create function get_titolo_pubblicazione (var_id_pubb int) returns varchar(100)
		READS SQL DATA
	
		begin
	
			return ( select titolo from Pubblicazione where id_pubblicazione = var_id_pubb );

		end $



#
# Reimposto il delimitatore originale
#
delimiter ;

#
# Questo script contiene delle utility che facilitano l utilizzo di alcune query e alcune procedure utili per la base di dati.
# Non vengono _create su tutte le possibili operazioni ma solo su alcune di quelle che si ritengono più adeguate
#


delimiter $


#
# Immaginando un form di registrazione ha senso unificare i dati di Utente e Anagrafica
# Viene quindi creata una procedura che prende i parametri passati dalla form e "smistati" alle rispettive query 
# aggiungi_utente e aggiungi_anagrafica presenti nel _file delle operazioni CRUD
#

drop procedure if exists login ;
create procedure login ( in var_email varchar(50) , in var_password varchar(50) ,OUT is_correct boolean )
	begin
		
    IF EXISTS(SELECT * FROM Utente WHERE email = var_email AND password = PASSWORD(var_password) ) then
        set is_correct = true;
    ELSE
         set is_correct = false;
    END IF;
		
	end $




drop procedure if exists registrazione ; 
create procedure registrazione 
			(		
				in email_utente 	varchar(250) ,
				in password_utente 	varchar(250) ,
				in _nome  			varchar(250) ,
				in _cognome 		varchar(250) ,
				in _cf 				varchar(250) ,
				in _datadinascita 	DATE		 ,
				in _luogodinascita 	varchar(250) ,
				in _nazione 		varchar(250)
			)
			
			begin
				
				# handler boolena che funziona da guardia _in caso di errore ( inizializzato a true -> passa a false _in caso di SQLExcpetion)
				
				declare all_ok BOOLEAN ;  
				
				declare var_id_utente int ;
				
				declare CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = false;	

				set all_ok = true;

				START TRANSACTION;

				call aggiungi_utente ( email_utente , password_utente );

				set var_id_utente = last_insert_id();

				call aggiungi_anagrafica( var_id_utente , _nome , _cognome , _cf , _datadinascita , _luogodinascita , _nazione );

				if not all_ok 
				
					then ROLLBACK;
				
					else COMMIT;
				
				end if;	

			end $			



# aggiunta pubblicazione
# procedura utilizzata per l inserimento di una pubblicazione che andrà a popolare le tabelle pubblicazione e Metadati

drop procedure if exists inserisci_pubblicazione ;
create procedure inserisci_pubblicazione 
		( 
			in _email				varchar(250) ,
			in _titolo_pubb 		varchar(250) ,
			in _categoria 			varchar(250) ,
			in _edizione			int			 ,
			in _editore				varchar(250) ,
			in _data_pubblicazione	DATE		 ,
			in _parole_chiave		varchar(250) ,
			in _isbn				BIGINT		 ,
			in _numPagine			int			 ,
			in _lingua				varchar(250) ,
			in _sinossi				varchar(1000)
		)
		begin
				
				declare all_ok BOOLEAN ;  
				
				declare _id_utente int ;
				
				declare var_descrizione varchar(100) ;
				
				declare id_pubb int ;
				
				declare CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = false;	

				set all_ok = true;

				START TRANSACTION;

				

					set _id_utente = get_id_utente(_email) ;
					
					call aggiungi_pubblicazione(_titolo_pubb , _categoria  );
					
					set var_descrizione = concat(' l utente ', _email ,' ha inserito una pubblicazione');
		
					
					call aggiorna_num_pubblicazione (_email );
				
					set id_pubb = last_insert_id();
			
					call aggiungi_storico( get_id_utente( _email ) , id_pubb , var_descrizione ,'INSERIMENTO PUBBLICAZIONE');
				
			
				
					call aggiungi_metadati ( id_pubb , _edizione , _editore , _data_pubblicazione , _parole_chiave ,_isbn , _numPagine , _lingua , _sinossi);

					
					
					
						if not all_ok 
				
							then ROLLBACK;
				
						else COMMIT;
				
						end if ;
		end $

#
# procedura per inserire un autore
#


drop procedure if exists inserisci_autore_pubblicazione ;
create procedure inserisci_autore_pubblicazione 
		(
			id_isbn			 	bigint ,
			nome_autore 		varchar(250),
			cognome_autore 		varchar(250)
		)
		begin
		
			declare var_id_autore 	int;

			declare l_id 	int ;
			
			declare all_ok BOOLEAN ;  

			declare CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = false;	

			set all_ok = true;

			START TRANSACTION;
			
			# mi salvo l id dell autore controllo se esiste
			#nel caso procedo solo all attribuzione. Se non esiste inserisco il novo autore e poi inserisco l attribuzione
			
			select id_autore  into var_id_autore from Autore where nome = nome_autore and cognome = cognome_autore ;
			
			if var_id_autore <> 0

				then

					call aggiungi_attribuzione ( id_isbn , var_id_autore ) ;

				else

					call aggiungi_autore ( nome_autore , cognome_autore ) ;

					set l_id = 	last_insert_id();

					call aggiungi_attribuzione ( id_isbn , l_id ) ;

			end if ;
			
			if not all_ok 

				then ROLLBACK;

				else COMMIT;

			end if;		
		
		
		end $










#
# procedura per inserire una  risorsa
#
# tipo e formato sono definiti , quindi 	
# potrebbe andare bene anche passare direttamente id_mediatype ma per sicurezza eseguo la query per recuperare l id e passo entrambi  i parametri 
# tipo e formato
#
# Assumo che uri e id_mediatype identifichino univocaente una risorsa
#


drop procedure if exists inserisci_risorsa_pubblicazione ;
create procedure inserisci_risorsa_pubblicazione
	(
		varemail		varchar(250),
		var_pubb 		int,
		var_uri 		varchar(250),
		var_descrizione varchar(500),
		var_tipo 		varchar(250),
		var_formato 	varchar(250)
	)

	begin

		declare var_storico varchar(100);

		declare var_id_utente	int;

		declare idmediatype int ;

		declare var_risorsa int ;

		declare l_id 		int ;
				
		declare all_ok BOOLEAN ;  
		
		declare CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = false;	
		
		set all_ok = true;
		
		
		START TRANSACTION;
		set var_id_utente = get_id_utente(varemail);
		
		set var_storico = concat('ha inserito una risorsa =>> uri-> ', var_uri , ' , var_descrizione-> ',var_descrizione);
		
		select id_mediatype into idmediatype from Mediatype where tipo = var_tipo and formato =  var_formato ;
		
		select id_risorsa into var_risorsa from Risorse where id_mediatype = idmediatype and uri = var_uri ;
		
		if var_risorsa <>  0
		
			then
				#la risorsa esiste , procedo solo ad associarla con la pubblicazione
			
				call aggiungi_link(var_pubb , var_risorsa );
		
				call aggiungi_storico( var_id_utente , var_pubb , var_storico , 'INSERIMENTO RISORSE' );
		
			else
				# creo la risorsa e la associo 
		
				call aggiungi_risorse( idmediatype , var_uri , var_descrizione);
		
				set l_id = 	last_insert_id();
		
				call aggiungi_link(var_pubb , l_id );
		
				call aggiungi_storico( var_id_utente , var_pubb , var_storico , 'INSERIMENTO RISORSE' );
		end if;
	
		
		
			if not all_ok 

				then ROLLBACK;

				else COMMIT;

			end if;		
		
		
		
		
	end $








#
# procedura per inserimento indice
#

drop procedure if exists inserimento_capitolo ;
create procedure inserimento_capitolo  (	varpubb int , vartitolo varchar(250) , vardescr varchar(250) , varnumcap 	int , varemail varchar(250) )

	begin
		
			declare var_storico varchar(100);

			declare var_id_utente	int;

			declare all_ok BOOLEAN ;  

			declare CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = false;	
	
			set all_ok = true;

			set var_storico = concat('ha inserito il capitolo ' , varnumcap);

			set var_id_utente = get_id_utente(varemail);

			START TRANSACTION;
			
			call aggiungi_capitolo ( varpubb , vartitolo , vardescr , varnumcap ) ;
		
			if not all_ok 

				then

				ROLLBACK ;

				else COMMIT ;

			end if ;

	end $




#
# PROCEDURA per togliere il _like , INVERSA di OPERAZIONE _11
#


		drop procedure if exists cancella_like ;
		create procedure cancella_like ( in IDPUBB int , in emailutente varchar(250) )
	
		BEGIN
	
			declare var_exist int ;
			DECLARE all_ok BOOLEAN;

			DECLARE CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = false;

			set all_ok = true;

			START TRANSACTION;


#devo gestire il caso in cui l utente inserisca più volte la rimozione del gradimento , 
#eseguo un _check , se presente procedo alla rimozione altrimenti nonfaccio nulla	
			
			if (select count(*) as count from Gradimento where id_utente =  get_id_utente ( emailutente ) and id_pubblicazione = IDPUBB ) = 1
			then 
			
			call cancella_gradimento( get_id_utente ( emailutente ) , IDPUBB );


			
			call togli_uno_a_like( IDPUBB ) ;
			
			call aggiungi_storico( get_id_utente ( emailutente ) , IDPUBB , 'l utente ha cancellato un like' ,'CANCELLAZIONE LIKE');
			end if ;
			if NOT all_ok 	
				THEN
					ROLLBACK;
				ELSE 	
					COMMIT;
			end if;				
		end $


#HANDLER PER OPERAZIONE 11 inversa
		drop procedure if exists togli_uno_a_like ;
		create procedure togli_uno_a_like(in IDPUBB int )
	
		BEGIN
	
			update Pubblicazione set numlike = numlike - 1  where id_pubblicazione = IDPUBB ;
		
		end $







#procedura per cancellare una recensione
drop procedure if exists elimina_recensione ;
		create procedure elimina_recensione(in IDPUBB int , in IDUTENTE int , in IDATTIVO int  )
	begin
		
		call cancella_recensione (IDUTENTE , IDPUBB) ;
		
		call aggiungi_storico( IDATTIVO , IDPUBB , 'l utente ha cancellato una recensione' ,'CANCELLAZIONE RECENSIONE');
		
		
	end $










#
# Reimposto il delimitatore
#



delimiter ;




delimiter $

# OPERAZIONE _1. Modifica del livello di un utente (da attivo a passivo e viceversa).
		
# l operazione viene divisa in due procedure 
#		_1)	operazione_permessi -> si occupa di controllare se l utente che la chiama è attivo e di chiamare aggiorna_tipo_utente			
#		_2)	aggiorna_tipo_utente -> effettua l upgrade/downgrade (modifica del tipo) dell utente
#			
# ometto volutamente i controlli sull email se non esiste la mail la query la fallisce per il vincolo referenziale
# e non effettuo il check sul tipo attivo , permetto il downgrade
		
		drop procedure if exists operazione_permessi ;
		create procedure operazione_permessi ( in email_utente varchar(250) , in email_utente_richiedente varchar(250) )
		
			BEGIN
			
				DECLARE err CONDITION FOR SQLSTATE '45000' ;
			
				if ( check_tipo_utente(email_utente_richiedente) <> 0 )
					then
						
						call aggiorna_tipo_utente ( email_utente );
			
					else
							
						SIGNAL err SET MESSAGE_TEXT = 'non si dispongono dei privilegi necessari per effettuare questa operazione ';				
				
				end if ;
				
				

			end $
			
		
		drop procedure if exists aggiorna_tipo_utente ; 
		create procedure aggiorna_tipo_utente (in email_utente varchar(250) )
		
			BEGIN
				
				DECLARE varq varchar(250) ;
		
				set varq =  (select tipo from Utente where email = email_utente );
		
				if  strcmp( varq , 'ATTIVO') = 1
		
				THEN
				
					call aggiorna_tipo_attivo(email_utente);
		
				ELSE
		
					call aggiorna_tipo_passivo(email_utente);
		
				end if;
				
			end $







# OPERAZIONE 2. Estrazione elenco delle ultime dieci pubblicazioni inserite.
#	La procedura è una semplice _select ; avendo aggiunto un attributo data inserimento 
#	ordiniamo il result _set per questa colonna e limitiamo il risultato alle prime 10   
#
		drop procedure if exists seleziona_ultime_dieci_pubblicazioni_inserite ; 
		create procedure seleziona_ultime_dieci_pubblicazioni_inserite( )

			begin
			
				select * from Pubblicazione order by data_inserimento DESC LIMIT 10 ;
	
			end $









# OPERAZIONE 3. Estrazione elenco delle pubblicazioni aggiornate di recente (ultimi 30 giorni)
#				
#		L operazione è basata su una _select dove il valore di data_ultima_modifica deve essere nell intervallo definito da CURRENT_TIMESTAMP - INTERVAL 30 DAY   
#
		drop procedure if exists seleziona_pubblicazioni_ultima_mod_30giorni ; 
		create procedure seleziona_pubblicazioni_ultima_mod_30giorni( )
	
			BEGIN
			
				select * from Pubblicazione where data_ultima_modifica between ( CURRENT_TIMESTAMP - INTERVAL 30 DAY)  and CURRENT_TIMESTAMP ; 
	
			end $









# OPERAZIONE 4. Estrazione elenco degli utenti più “collaborativi” (cioè quelli che hanno inserito più pubblicazioni).
#			
#		 Il parametro "numutenti" è il numero per il limit . Nell operazione non è definito quindi rendo parametrica la query
#

		drop procedure if exists seleziona_utenti_piu_collaborativi ; 
		create procedure seleziona_utenti_piu_collaborativi( in numutenti int )
	
			BEGIN
	
				select * from Utente order by num_inserimenti DESC LIMIT numutenti ;
	
			end $










# OPERAZIONE 5. Estrazione elenco delle pubblicazioni inserite da un utente.
#
#
		drop procedure if exists seleziona_pubblicazioni_inserite_da_un_utente ;
		create procedure seleziona_pubblicazioni_inserite_da_un_utente( in emailutente varchar(250) )
	
		BEGIN
			 select * from Pubblicazione join Storico on Pubblicazione.id_pubblicazione = Storico.id_pubblicazione 
	
				 	where Storico.id_utente  = get_id_utente(emailutente) AND operazione ='INSERIMENTO PUBBLICAZIONE';
		end $






# OPERAZIONE 6. Estrazione catalogo, cioè elenco di tutte le pubblicazioni con titolo, autori, editore e anno di pubblicazione, ordinato per titolo.
#
#			
#
#

		drop procedure if exists estrazione_catalogo ;
		create procedure estrazione_catalogo()
	
		BEGIN
 				select	* from view_pubblicazione_autori order by titolo ;
		end $






# OPERAZIONE 7. Estrazione dati completi di una pubblicazione specifica dato il suo ID.
#
#			query identica alla precedente limitata ad un preciso id_pubblicazione 
#

		drop procedure if exists estrazione_pubblicazione_dato_id ;
		create procedure estrazione_pubblicazione_dato_id ( in IDPUBB int)

		BEGIN

			select	* from view_pubblicazione_autori  where id_pubblicazione = IDPUBB ;

		end $


# OPERAZIONE 8. Ricerca di pubblicazioni per ISBN, titolo, autore, e parole chiave.
#
#			Non posso effettuare le ricerche _in un unica query ISBN è un BIGINT,tutti gl altri sono _varchar
#			Splitto la query _in _2
#					_1) per la ricerca tramite isbn 
#					_2) per tutte le altre passando come parametro il tipo di query desiderata [TITOLO , AUTORE , PAROLECHIAVE ]
#


# Query _1 per ricerca con ISBN

		drop procedure if exists ricerca_per_isbn ;
		create procedure ricerca_per_isbn ( in var_isbn bigint )
		
		begin
		
				select Pubblicazione.titolo from Pubblicazione
							
							join Metadati on Pubblicazione.id_pubblicazione = Metadati.id_pubblicazione
				
							where Metadati.isbn LIKE CONCAT('%', var_isbn , '%') ;  
		
		end $


# Query _2 per le ricerca basate su _varchar
#
# Utilizzo degli if per filtrare il tipo di ricerca e poi eseguo le query con la keyword _LIKE. Così anche se incomplete la ricerca produrrà come risultato
# le pubblicazioni che conterrano la var_search
#
/*

drop procedure if exists ricerca ;
		create procedure ricerca ( in var_titolo varchar(250) , in var_autori varchar(20),in var_isbn int , in var_parolechiave varchar(20))
select * from view_pubblicazione_autori 
		
			where Autori LIKE CONCAT('%', var_autori , '%') 
		
			OR titolo LIKE CONCAT('%', var_titolo, '%') 
		 
		 	OR parole_chiave LIKE CONCAT('%', var_parolechiave , '%') 
		 	
		 	OR isbn LIKE CONCAT('%', var_isbn , '%') ;

end




*/


		drop procedure if exists ricerca ;
		create procedure ricerca ( in var_search varchar(250) , var_tipo varchar(20))

		BEGIN
		
				DECLARE err CONDITION FOR SQLSTATE '45000' ;
		
				if strcmp( var_tipo , 'TITOLO') = 0
				
				then
				
						select titolo From Pubblicazione where titolo LIKE CONCAT('%', var_search , '%') ;
				
				elseif  strcmp( var_tipo , 'AUTORE') = 0 then
				
						#effettua la ricerca per autore
				
						select Pubblicazione.titolo , Metadati.isbn ,Autore.nome , Autore.cognome from Pubblicazione 
							
								join Metadati on Pubblicazione.id_pubblicazione = Metadati.id_pubblicazione
								
								join Attribuzione on Metadati.isbn = Attribuzione.isbn
								
								join Autore on Attribuzione.id_autore = Autore.id_autore
								
								where Autore.nome LIKE CONCAT('%', var_search , '%')  OR Autore.cognome LIKE CONCAT('%', var_search , '%') ;
														
				elseif 	strcmp( var_tipo , 'PAROLECHIAVE') = 0 then
				
						#effettua la ricerca per parole chiave
				
						select Pubblicazione.titolo  from Pubblicazione 
						
								join Metadati on Pubblicazione.id_pubblicazione = Metadati.id_pubblicazione 
								
								where Metadati.parole_chiave LIKE CONCAT('%', var_search , '%') ;

				else
						#errore_ricerca nel caso il parametro non si _in [ TITOLO , AUTORE , PAROLECHIAVE ]

						SIGNAL err SET MESSAGE_TEXT = 'errore ricerca , parametro di filtraggio non riconosciuto ';

				end if ;	
		end $





# OPERAZIONE 9. Inserimento di una recensione relativa a una pubblicazione.
#					
#



		drop procedure if exists inserimento_recensione ;
		create procedure inserimento_recensione ( in emailutente varchar(250) , in id_pubb int ,in TESTO varchar(1000)	)
		
		BEGIN
			DECLARE all_ok BOOLEAN;
			DECLARE var_descrizione varchar(100);
			DECLARE CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = true;
		
			
		
			START TRANSACTION;
			set var_descrizione = concat(' l utente ',emailutente,' ha inserito una recensione');
			call aggiungi_recensione(get_id_utente(emailutente) , id_pubb, TESTO );	
			call aggiungi_storico( get_id_utente( emailutente ) , id_pubb , var_descrizione ,'INSERIMENTO RECENSIONE');
		
			if NOT all_ok 
			THEN
				ROLLBACK;
			ELSE 
				COMMIT;
			end if;	
		
		end $






# OPERAZIONE 10. Approvazione o di una recensione (da parte del moderatore).
#
#	Questa query è limitata a utenti ATTIVI
#

		drop procedure if exists approva_recensione ;
		create procedure approva_recensione( in IDUTENTE int , in IDPUBB int , in emailutente varchar(250) )

		BEGIN	



			DECLARE all_ok BOOLEAN;

			DECLARE var_descrizione varchar(250);

			DECLARE CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = true;
						
			if ( check_tipo_utente( emailutente ) <> 0 )
			
				then		
			
					START TRANSACTION;
			
					call aggiorna_stato_recensione( IDUTENTE , IDPUBB );	

					set var_descrizione = CONCAT('l utente attivo ', emailutente ,' ha approvato la recensione di ', get_email_by_id(IDUTENTE) );
		
					call aggiungi_storico( get_id_utente( emailutente ) , IDPUBB , var_descrizione ,'MODIFICA RECENSIONE');
				
					if NOT all_ok 
						
						THEN
							
								ROLLBACK;
						ELSE 
							
							COMMIT;

					end if;	
				
			else
							
				select 'non si dispongono dei privilegi necessari per effettuare questa operazione ' as Errore;				
					
			end if ;	
	
				
						
	
	
		end $	









# OPERAZIONE 11. Inserimento di un like_ relativo a una pubblicazione.
#
#	Operazione consentita solo ad utenti attivi . Utilizza un Handler per il plus_one
#
#

		drop procedure if exists aggiungi_like ;
		create procedure aggiungi_like ( in IDPUBB int , in emailutente varchar(250) )
	
		BEGIN
	
			DECLARE all_ok BOOLEAN;

			DECLARE CONTINUE HANDLER FOR SQLEXCEPTION set all_ok = false;

			set all_ok = true;

			START TRANSACTION;
	
			call aggiungi_gradimento( get_id_utente ( emailutente ) , IDPUBB );

			call aggiungi_uno_a_like( IDPUBB ) ;
			
			call aggiungi_storico( get_id_utente ( emailutente ) , IDPUBB , 'l utente ha inserito un like' ,'INSERIMENTO LIKE');

			if NOT all_ok 	
				THEN
					ROLLBACK;
				ELSE 	
					COMMIT;
			end if;				
		end $



#HANDLER PER OPERAZIONE 11
		drop procedure if exists aggiungi_uno_a_like ;
		create procedure aggiungi_uno_a_like(in IDPUBB int )
	
		BEGIN
	
			update Pubblicazione set numlike = numlike + 1  where id_pubblicazione = IDPUBB ;
		
		end $







# OPERAZIONE 12. Calcolo numero dei like_ per una pubblicazione.
		drop procedure if exists calcolo_numero_like ;
		create procedure calcolo_numero_like ( in IDPUBB int )
	
		BEGIN
	
			select numlike from Pubblicazione where id_pubblicazione = IDPUBB ;
	
		end $








# OPERAZIONE 13. Estrazione elenco delle recensioni approvate per una pubblicazione.
		drop procedure if exists elenco_recensioni_approvate_pubblicazione ;
		create procedure elenco_recensioni_approvate_pubblicazione ( in IDPUBB int)
	
		BEGIN
		
			select get_email_by_id(id_utente ) as email , data , testo from Recensione where id_pubblicazione = IDPUBB and stato = 'APPROVATA';
	
		end $







# OPERAZIONE 14. Estrazione elenco delle recensioni in_ attesa di approvazione.
#
#	
#
		drop procedure if exists elenco_recensioni_in_attesa ;
		create procedure elenco_recensioni_in_attesa ( in emailutente varchar(250) )
	
		BEGIN
				
			DECLARE err CONDITION FOR SQLSTATE '45000' ;

			if ( check_tipo_utente(emailutente) <> 0 )

				then
	
					select * from Recensione where stato = 'in ATTESA';

			else
							
					SIGNAL err SET MESSAGE_TEXT = 'non si dispongono dei privilegi necessari per effettuare questa operazione ';				
					
			end if ;	
	
		end $







# OPERAZIONE 15. Estrazione log_ delle modifiche effettuate su una pubblicazione.

		drop procedure if exists log_modifiche;
		create procedure modifica_log(in id_pubb int)
		begin
				select * from Storico where id_pubblicazione = id_pubb and operazione = 'MODIFICA PUBBLICAZIONE';
		end $


# OPERAZIONE 16. Estrazione elenco delle pubblicazioni per le quali è disponibile un download.

		drop procedure if exists pubblicazioni_con_download ;
		create procedure pubblicazioni_con_download()
		
		begin
		
			select * from view_pubblicazione_download ;	
		
		end $


#
# OPERAZIONE 17. Estrazione della lista delle pubblicazioni in_ catalogo, ognuna con la data dell’ultima ristampa 
# 

	drop procedure if exists elenco_pubblicazioni_ultima_ristampa ;
	create procedure elenco_pubblicazioni_ultima_ristampa()

	BEGIN

		select Pubblicazione.titolo , max(Versione_Stampa.data_stampa) From Pubblicazione
		
			JOIN Metadati on Pubblicazione.id_pubblicazione = Metadati.id_pubblicazione 
			
			JOIN Versione_Stampa on Metadati.isbn = Versione_Stampa.isbn GROUP BY Pubblicazione.titolo ;
		
	end $


# OPERAZIONE 18. Data una pubblicazione, restituire tutte le pubblicazioni aventi gli stessi autori
#





	drop procedure if exists elenco_pubblicazioni_stessi_autori_tre ;
	create procedure elenco_pubblicazioni_stessi_autori_tre( in id_pubb int )

	begin

		select * from view_pubblicazione_autori 
			where Autori = ( select Autori from view_pubblicazione_autori where id_pubblicazione =id_pubb ) and id_pubblicazione <> id_pubb ;

	end $





# reimposto il delimiter

delimiter ;
#
# Questo script conterrà solo i _trigger
#
DELIMITER $

#
# TRIGGER STORICO
#
#--	Questo trigger controlla che l operazione inserita sia conforme a quelle permesse come descritto nella documentazione
#


drop trigger if exists storico_trg;
create trigger storico_trg

	before insert on Storico FOR EACH ROW 
	BEGIN 

		
	if ( select   ( strcmp (NEW.operazione ,'INSERIMENTO PUBBLICAZIONE') = 0 
		     	 OR strcmp ( NEW.operazione,'CANCELLAZIONE PUBBLICAZIONE') = 0
				 OR strcmp ( NEW.operazione,'MODIFICA PUBBLICAZIONE') = 0
		 		 OR strcmp ( NEW.operazione,'INSERIMENTO RECENSIONE') = 0 
		 		 OR strcmp ( NEW.operazione,'CANCELLAZIONE RECENSIONE') = 0
			     OR strcmp ( NEW.operazione,'MODIFICA RECENSIONE') = 0 
			     OR strcmp ( NEW.operazione,'INSERIMENTO RISORSE') = 0 
		 		 OR strcmp ( NEW.operazione,'CANCELLAZIONE RISORSE') = 0
			     OR strcmp ( NEW.operazione,'MODIFICA RISORSE') = 0 
	    		 OR strcmp ( NEW.operazione,'INSERIMENTO LIKE') = 0
 				 OR strcmp ( NEW.operazione,'CANCELLAZIONE LIKE') = 0		
       			  )
		 =  0 )
		 	then 
				signal sqlstate '45000' set message_text='operazione non consentita';
	
			end if ;
	end $




# TRIGGER RECENSIONE
# Una recensione è inserita da un utente attivo non necessita di essere moderata. Viene quindi aggiornato immediatamente lo stato in 'APPROVATA'
#
#

drop trigger if exists recensione_trg;
create trigger recensione_trg
before insert on Recensione FOR EACH ROW 
	BEGIN 

		if ( check_tipo_id_utente(NEW.id_utente) <> 0 )
		then
			set NEW.stato = 'APPROVATA' ;
		end if;
	end $


#
# -- Trigger anagrafica -> La data di Nascita non può essere superiore alla data odierna
#

drop trigger if exists anagrafica_trg;
create trigger anagrafica_trg
before insert on Anagrafica FOR EACH ROW 
	BEGIN 

	DECLARE err CONDITION FOR SQLSTATE '45000' ;
			
		if New.data_nascita > NOW()
		then
			SIGNAL err SET MESSAGE_TEXT = 'la data inserita non è valida ';
		end if;
	end $



#trigger pubblicazione che aggiorna la data dell ultima modifica 


drop trigger if exists modifica_pubblicazione_trg;
create trigger modifica_pubblicazione_trg 
before UPDATE on Pubblicazione FOR EACH ROW 
	BEGIN 
		 set NEW.data_ultima_modifica = CURRENT_TIMESTAMP ;
	end $
	
	

-- le categorie che vengono supportate dalla base di dati sono limitate a  TESI , REPORT , ARTICOLO , LIBRO
drop trigger if exists insert_pubblicazione_trg;
create trigger insert_pubblicazione_trg 
before INSERT on Pubblicazione FOR EACH ROW 
	BEGIN 
	if ( select   ( strcmp (NEW.categoria ,'TESI') = 0 
		     	 OR strcmp ( NEW.categoria,'REPORT') = 0
				 OR strcmp ( NEW.categoria,'ARTICOLO') = 0
		 		 OR strcmp ( NEW.categoria,'LIBRO') = 0 
		 		
       			  )
		 =  0 )
		 	then 
				signal sqlstate '45000' set message_text='categoria non consentita';
	
			end if ;
	end $



drop trigger if exists versione_stampa_trg;
create trigger versione_stampa_trg 
before INSERT on Versione_Stampa FOR EACH ROW 
	begin
		declare var_date date ;	
		
		declare maxdate date ;	
		
		select data_pubblicazione into var_date from Metadati where isbn = NEW.isbn ;
		select max(data_stampa) into maxdate from Versione_Stampa where isbn = NEW.isbn ;
		if NEW.data_stampa < var_date
			then
				signal sqlstate '45000' set message_text='errore : la data della stampa non può essere inferiore a quella di pubblicazione ';
		end if ;
		 
	
		if NEW.data_stampa < maxdate
			then
				signal sqlstate '45000' set message_text='errore : la data dell ultima stampa inserita  ';
		end if ;
	end $


delimiter ;


delimiter $


drop procedure if exists  modifica_edizione_metadati;
create procedure modifica_edizione_metadati (in EDI int , in _ISBN BIGINT , in _email varchar(50) )
	
	begin
	if ( check_tipo_utente(_email) <> 0 )
		then						
			call aggiorna_edizione_metadati (EDI,  _ISBN );
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( _ISBN ) , 'modificata edizione ' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $





drop procedure if exists  modifica_editore_metadati ;
create procedure modifica_editore_metadati (in EDI varchar(50) , in __ISBN BIGINT , in _email varchar(50) )
	
	begin
		if ( check_tipo_utente(_email) <> 0 )
		then
			call aggiorna_editore_metadati(EDI , __ISBN );
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( __ISBN ) , 'modificato editore ' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $





drop procedure if exists  modifica_data_pubblicazione_metadati ;
create procedure modifica_data_pubblicazione_metadati (in DATAPUBB DATE , in _ISBN BIGINT , in _email varchar(50)  )
	
	begin
		if ( check_tipo_utente(_email) <> 0 )
		then
			call aggiorna_data_pubblicazione_metadati( DATAPUBB,_ISBN );
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( _ISBN ) , 'modificata data pubblicazione' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $





drop procedure if exists  modifica_parole_chiave_metadati ;
create procedure modifica_parole_chiave_metadati (in PAROLECHIAVE varchar(250) , in _ISBN BIGINT  ,in _email varchar(50) )
	
	begin
		if ( check_tipo_utente(_email) <> 0 )
		then
			call aggiorna_parole_chiave_metadati(PAROLECHIAVE, _ISBN) ;
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( _ISBN ) , 'modificate parole chiave' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $






drop procedure if exists  modifica_isbn_metadati ;
create procedure modifica_isbn_metadati (in _ISBNNEW int(13), in _ISBN BIGINT ,in _email varchar(50)  )
	
	begin
		if ( check_tipo_utente(_email) <> 0 )
		then
			call aggiorna_isbn_metadati(_ISBNNEW ,_ISBN ) ;
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( _ISBN ) , 'modificato isbn' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $






drop procedure if exists  modifica_num_pagine_metadati ;
create procedure modifica_num_pagine_metadati (in NUMPAGINE int,in _ISBN BIGINT , in _email varchar(50) )
	
	begin
		if ( check_tipo_utente(_email) <> 0 )
		then
			call aggiorna_num_pagine_metadati(NUMPAGINE , _ISBN );
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( _ISBN ) , 'modificato num pagine' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $







drop procedure if exists  modifica_lingua_metadati ;
create procedure modifica_lingua_metadati (in LINGUA varchar(250),in _ISBN BIGINT , in _email varchar(50) )
	
	begin
		if ( check_tipo_utente(_email) <> 0 )
		then
			call aggiorna_lingua_metadati( LINGUA , _ISBN);
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( _ISBN ) , 'modificata lingua' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $







drop procedure if exists  modifica_sinossi_metadati ;
create procedure modifica_sinossi_metadati (in SINOSSI varchar(1000) , in _ISBN BIGINT ,in _email varchar(50)  )
	
	begin
		if ( check_tipo_utente(_email) <> 0 )
		then
			call aggiorna_sinossi_metadati(SINOSSI , _ISBN);
			call aggiungi_storico( get_id_utente( _email ) , get_id_pubblicazione_by_isbn( _ISBN ) , 'modificata sinossi' ,'MODIFICA PUBBLICAZIONE');
		end if ;
	end $






delimiter ;








drop view if exists view_pubblicazione_autori ;
create view view_pubblicazione_autori as

	
	select pubb.titolo,pubb.categoria  , met.* ,
 				
 							GROUP_CONCAT( concat (Autore.nome , ' ', Autore.cognome) separator ' , ') as Autori from Pubblicazione as pubb

							join Metadati as met on pubb.id_pubblicazione = met.id_pubblicazione  

							join Attribuzione on met.isbn = Attribuzione.isbn  

							join Autore on Attribuzione.id_autore = Autore.id_autore group by met.isbn order by pubb.titolo ;
	
	




drop view if exists view_pubblicazione_download;
create view view_pubblicazione_download as

		select Pubblicazione.titolo from Pubblicazione 
					
					join Link on Pubblicazione.id_pubblicazione = Link.id_pubblicazione
					
					join Risorse on Link.id_risorsa = Risorse.id_risorsa
					
					join Mediatype on Risorse.id_mediatype = Mediatype.id_mediatype
					
						where Mediatype.tipo = 'DOWNLOAD' ; 	
						
						
#aggiunta Utenti

DELETE FROM Utente ;

call aggiungi_utente('tommasodisalle@gmail.com','passwd');
call aggiungi_utente('danielecampli@gmail.com','passwd');
call aggiungi_utente('pippo@gmail.com','passwd');
call aggiungi_utente('pluto@gmail.com','passwd');
call aggiungi_utente('paperino@gmail.com','passwd');
call aggiungi_utente('minnie@gmail.com','passwd');
call aggiungi_utente('topolino@gmail.com','passwd');
call aggiungi_utente('uno@gmail.com','passwd');
call aggiungi_utente('due@gmail.com','passwd');
call aggiungi_utente('tre@gmail.com','passwd');


#aggiunta Anagrafica

DELETE FROM Anagrafica ;

call aggiungi_anagrafica(1,'tommaso','di salle','dsltms86e11g878o'  ,'1990-05-11','popoli','italia');
call aggiungi_anagrafica(2,'daniele','campli'  ,'aemndj67u32l912t'  ,'1991-07-20','popoli','italia');
call aggiungi_anagrafica(3,'pippo','disalle'   ,'moiuad99a23d712h'  ,'1981-08-30','popoli','italia');
call aggiungi_anagrafica(4,'pluto','disalle'   ,'moasqh22j54w345s'  ,'1971-01-31','popoli','italia');
call aggiungi_anagrafica(5,'paperino','disalle','asdhjw90m76p789r'  ,'1992-10-13','popoli','italia');
call aggiungi_anagrafica(6,'minnie','disalle'  ,'bbnmqw77a87d567b'  ,'1985-11-14','popoli','italia');
call aggiungi_anagrafica(7,'topolino','disalle','pzpzpz62a28s678y'  ,'1999-12-15','popoli','italia');
call aggiungi_anagrafica(8,'uno','disalle'	   ,'papaox88j91e266x'  ,'1987-03-23','popoli','italia');
call aggiungi_anagrafica(9,'due','disalle'     ,'qozmei57a13o897w'  ,'2000-05-25','popoli','italia');
call aggiungi_anagrafica(10,'tre','disalle'    ,'mxmxmx89i13j390p'  ,'1994-04-26','popoli','italia');

#aggiunta Pubblicazioni

DELETE FROM Pubblicazione;
call aggiungi_pubblicazione ('titolo_capitoloolo1','REPORT');
call aggiungi_pubblicazione ('titolo_capitoloolo2','LIBRO');
call aggiungi_pubblicazione ('titolo_capitoloolo3','TESI');
call aggiungi_pubblicazione ('titolo_capitoloolo4','ARTICOLO');
call aggiungi_pubblicazione ('titolo_capitoloolo5','ARTICOLO');
call aggiungi_pubblicazione ('titolo_capitoloolo6','TESI');
call aggiungi_pubblicazione ('titolo_capitoloolo7','LIBRO');
call aggiungi_pubblicazione ('titolo_capitoloolo8','REPORT');
call aggiungi_pubblicazione ('titolo_capitoloolo9','ARTICOLO');
call aggiungi_pubblicazione ('titolo_capitoloolo9','REPORT');


#aggiunta metadati

DELETE FROM Metadati;
#ins   dati value (IDPUBB, EDIZIONE ,EDITORE,DATAPUBB ,PAROLECHIAVE ,ISBN ,NUMPAGINE ,LINGUA ,SINOSSI);						
call aggiungi_metadati(1, 2 ,'editore1','1800-01-01' ,'par1 par2 par3' ,1 ,987 ,'italiana' ,'abstract pubblicazione1' );
call aggiungi_metadati(2, 1 ,'editore2','1800-01-01' ,'par1 par2 par3' ,2 ,987 ,'bulgara' ,'abstract pubblicazione2' );
call aggiungi_metadati(3, 1 ,'editore3','1800-01-01' ,'par1 par2 par3' ,3 ,987 ,'italiana' ,'abstract pubblicazione3' );
call aggiungi_metadati(4, 1 ,'editore4','1800-01-01' ,'par1 par2 par3' ,4 ,987 ,'svizzera' ,'abstract pubblicazione4' );
call aggiungi_metadati(5, 1 ,'editore5','1800-01-01' ,'par1 par2 par3' ,5 ,987 ,'italiana' ,'abstract pubblicazione5' );
call aggiungi_metadati(6, 1 ,'editore6','1800-01-01' ,'par1 par2 par3' ,6 ,987 ,'francese' ,'abstract pubblicazione6' );
call aggiungi_metadati(7 ,1 ,'editore3','1800-01-01' ,'par1 par2 par3' ,7 ,987 ,'inglese' ,'abstract pubblicazione3' );
call aggiungi_metadati(8, 1 ,'editore4','1800-01-01' ,'par1 par2 par3' ,8 ,987 ,'italiana' ,'abstract pubblicazione4' );
call aggiungi_metadati(9, 1 ,'editore5','1800-01-01' ,'par1 par2 par3' ,9 ,987 ,'giapponese' ,'abstract pubblicazione5' );
call aggiungi_metadati(10, 1 ,'editore6','1800-01-01' ,'par1 par2 par3' ,10 ,987 ,'italiana' ,'abstract pubblicazione6' );

#aggiunti autori
call aggiungi_autore('isaac','newton');
call aggiungi_autore('paul','erdos');
call aggiungi_autore('claude','shannon');
call aggiungi_autore('dennis','ritchie');
call aggiungi_autore('ken','thompson');
call aggiungi_autore('vincenzo','stoico');
call aggiungi_autore('eugenio','mancini');
call aggiungi_autore('leonardo','da vinci');
call aggiungi_autore('nikola','tesla');
call aggiungi_autore('alan','turing');
call aggiungi_autore('giacomo','leopardi');
call aggiungi_autore('giuseppe','verdi');
call aggiungi_autore('giacomo','pucci');
call aggiungi_autore('tommaso','di salle');
call aggiungi_autore('daniele','campli');

call aggiungi_capitolo(1,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(1,'titolo_capitolo','desc2',2);
call aggiungi_capitolo(1,'titolo_capitolo','desc3',3);
call aggiungi_capitolo(1,'titolo_capitolo','desc4',4);
call aggiungi_capitolo(1,'titolo_capitolo','desc5',5);
call aggiungi_capitolo(1,'titolo_capitolo','desc6',6);
call aggiungi_capitolo(1,'titolo_capitolo','desc7',7);
call aggiungi_capitolo(1,'titolo_capitolo','desc8',8);
call aggiungi_capitolo(2,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(2,'titolo_capitolo','desc2',2);
call aggiungi_capitolo(2,'titolo_capitolo','desc3',3);
call aggiungi_capitolo(2,'titolo_capitolo','desc4',4);
call aggiungi_capitolo(2,'titolo_capitolo','desc5',5);
call aggiungi_capitolo(2,'titolo_capitolo','desc6',6);
call aggiungi_capitolo(2,'titolo_capitolo','desc7',7);
call aggiungi_capitolo(2,'titolo_capitolo','desc8',8);
call aggiungi_capitolo(3,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(3,'titolo_capitolo','desc2',2);
call aggiungi_capitolo(3,'titolo_capitolo','desc3',3);
call aggiungi_capitolo(3,'titolo_capitolo','desc4',4);
call aggiungi_capitolo(3,'titolo_capitolo','desc5',5);
call aggiungi_capitolo(3,'titolo_capitolo','desc6',6);
call aggiungi_capitolo(3,'titolo_capitolo','desc7',7);
call aggiungi_capitolo(3,'titolo_capitolo','desc8',8);
call aggiungi_capitolo(4,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(5,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(6,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(7,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(8,'titolo_capitolo','desc1',1);
call aggiungi_capitolo(9,'titolo_capitolo','desc1',1);

call aggiungi_versione_stampa(1, 1, '1987-7-13');
call aggiungi_versione_stampa(2, 1, '1961-2-28');
call aggiungi_versione_stampa(3, 1, '1954-5-3');
call aggiungi_versione_stampa(4, 1, '2015-6-16');
call aggiungi_versione_stampa(5, 1, '1959-4-26');
call aggiungi_versione_stampa(6, 1, '1968-5-12');


call aggiungi_mediatype('tipo1','formato1');
call aggiungi_mediatype('tipo2','formato2');
call aggiungi_mediatype('tipo3','formato3');
call aggiungi_mediatype('tipo4','formato4');
call aggiungi_mediatype('tipo5','formato5');
call aggiungi_mediatype('tipo6','formato6');
call aggiungi_mediatype('tipo7','formato7');
call aggiungi_mediatype('tipo8','formato8');


call aggiungi_risorse(1,'uri1','desc1');
call aggiungi_risorse(2,'uri2','desc2');
call aggiungi_risorse(3,'uri3','desc3');
call aggiungi_risorse(4,'uri4','desc4');
call aggiungi_risorse(5,'uri5','desc5');
call aggiungi_risorse(6,'uri6','desc6');
call aggiungi_risorse(7,'uri7','desc7');
call aggiungi_risorse(8,'uri8','desc8');


call aggiungi_recensione(1,1,'testo1');
call aggiungi_recensione(1,2,'testo2');
call aggiungi_recensione(1,3,'testo3');
call aggiungi_recensione(1,4,'testo4');
call aggiungi_recensione(1,5,'testo5');
call aggiungi_recensione(1,6,'testo6');
call aggiungi_recensione(1,7,'testo7');
call aggiungi_recensione(2,3,'testo9');
call aggiungi_recensione(2,4,'testo10');
call aggiungi_recensione(2,5,'testo11');
call aggiungi_recensione(3,6,'testo12');
call aggiungi_recensione(3,7,'testo13');
call aggiungi_recensione(4,8,'testo14');
call aggiungi_recensione(4,1,'testo15');
call aggiungi_recensione(5,2,'testo16');


call aggiungi_gradimento(1 , 1);
call aggiungi_gradimento(1 , 2);
call aggiungi_gradimento(1 , 3);
call aggiungi_gradimento(1 , 4);
call aggiungi_gradimento(2 , 1);
call aggiungi_gradimento(2 , 2);
call aggiungi_gradimento(2 , 3);
call aggiungi_gradimento(3 , 1);
call aggiungi_gradimento(3 , 2);
call aggiungi_gradimento(3 , 3);
call aggiungi_gradimento(3 , 4);
call aggiungi_gradimento(4 , 1);
call aggiungi_gradimento(4 , 2);
call aggiungi_gradimento(4 , 3);
call aggiungi_gradimento(4 , 4);



call aggiungi_attribuzione(1 , 1);
call aggiungi_attribuzione(1 , 2);
call aggiungi_attribuzione(1 , 3);
call aggiungi_attribuzione(1 , 4);
call aggiungi_attribuzione(2 , 1);
call aggiungi_attribuzione(2 , 2);
call aggiungi_attribuzione(2 , 3);
call aggiungi_attribuzione(3 , 1);
call aggiungi_attribuzione(3 , 2);
call aggiungi_attribuzione(4 , 1);
call aggiungi_attribuzione(4 , 2);


call aggiungi_storico(1,1,'inserita pubblicazione' , 'INSERIMENTO PUBBLICAZIONE');
call aggiungi_storico(1,2,'inserita pubblicazione' , 'INSERIMENTO PUBBLICAZIONE');
call aggiungi_storico(2,3,'inserita pubblicazione' , 'INSERIMENTO PUBBLICAZIONE');
call aggiungi_storico(2,4,'inserita pubblicazione' , 'INSERIMENTO PUBBLICAZIONE');
call aggiungi_storico(3,5,'inserita pubblicazione' , 'INSERIMENTO PUBBLICAZIONE');

call aggiungi_link( 1, 1);
call aggiungi_link( 1, 2);
call aggiungi_link( 1, 3);
call aggiungi_link( 2, 1);
call aggiungi_link( 2, 3);
call aggiungi_link( 2, 4);
call aggiungi_link( 3, 5);
call aggiungi_link( 3, 6);
call aggiungi_link( 3, 7);
call aggiungi_link( 4, 6);
call aggiungi_link( 4, 7);
call aggiungi_link( 4, 8);
